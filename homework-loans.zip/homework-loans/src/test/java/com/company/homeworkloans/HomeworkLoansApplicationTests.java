package com.company.homeworkloans;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HomeworkLoansApplicationTests {

	@Test
	void contextLoads() {
	}

}
